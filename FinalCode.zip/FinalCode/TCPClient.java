import java.io.*; 
import java.net.*;
import java.util.Scanner;
import java.security.KeyPair;

class TCPClient { 
	public static final int UNENCRYP_MODE = 1, ENCRYP_MODE = 2, ENCRYP_WITH_SIGN_MODE = 3;
	public static final String MALFORMED_USERNAME = "ERROR 100 Malformed username"; 
	public static final String USER_NOTFOUND = "ERROR 101 No user registered"; 
	public static final String UNABLE_TOSEND = "ERROR 102 Unable to send"; 
	public static final String HEADER_INCOMPLETE = "ERROR 103 Header incomplete"; 
	public static final String INCOMPATIBLE_MODE = "ERROR 104 Incompatible mode"; 
	public static final String MALFORMED_REQUEST = "ERROR 105 Malformed request";
	public static final String MSG_LEN_NOT_FOUND = "ERROR 106 Message length missing";
	public static final String USER_ALREADY_REG = "ERROR 107 User already registered"; 
	public static final int REQUEST_LIMIT = 2;
	public static final int WAIT_TIME = 1000;

	private static BufferedReader inFromUser, inFromServerSender, inFromServerReceiver;
	private static DataOutputStream outToServerReceiver, outToServerSender;
	private static String username, ipAddr;
	private static int mode = UNENCRYP_MODE;

	public static void main(String argv[]) throws Exception 
	{ 
		String serverMsg, endln;


		inFromUser = new BufferedReader(new InputStreamReader(System.in)); 
		if(argv.length!=3 && argv.length != 2){
			System.out.println("Invalid arguments. Please enter arguments in the order of Username, IP Address and mode"); 
			return;    
		}
		username = argv[0];
		ipAddr = argv[1];
		if(argv.length == 3)
			mode = Integer.parseInt(argv[2]); 
		while(mode!=UNENCRYP_MODE && mode!=ENCRYP_MODE && mode!=ENCRYP_WITH_SIGN_MODE){
			System.out.printf("Invalid arguments. Please enter valid mode: "); 
			Scanner scn = new Scanner(System.in);
			try{
				mode = scn.nextInt();
				scn.close();
			}catch(Exception e){
				System.out.println("\nreturnning...");
				return;
			}
		}

		TCPClient.Register();
	}

	public static void Register() {
		try{
			KeyPair keyPair = Cryptography.generateKeyPair();
			byte[] publicKey = keyPair.getPublic().getEncoded();
			byte[] privateKey = keyPair.getPrivate().getEncoded();
			String publicKeyString  = java.util.Base64.getEncoder().encodeToString(publicKey);

			Socket sendMessageSocket = new Socket(ipAddr, 6789);
			boolean statusRec, statusSend;
			outToServerSender = new DataOutputStream(sendMessageSocket.getOutputStream());         

			inFromServerSender = new BufferedReader(new InputStreamReader(sendMessageSocket.getInputStream())); 

			statusSend = registerToSend();
			if(!statusSend) {
				sendMessageSocket.close();
				return;
			}
			Socket recieveMessageSocket = new Socket(ipAddr, 6789);
			outToServerReceiver = new DataOutputStream(recieveMessageSocket.getOutputStream());
			inFromServerReceiver = new BufferedReader(new InputStreamReader(recieveMessageSocket.getInputStream()));
			statusRec = registerToRecv();
			if(!statusRec) {
				sendMessageSocket.close();
				recieveMessageSocket.close();
				return;
			}
			boolean statusMode = verifyMode();
			if(!statusMode) {				
				sendMessageSocket.close();
				recieveMessageSocket.close();
				return;
			}
			if(mode!=UNENCRYP_MODE){			
				boolean statusKey =  sendPublickey(publicKeyString);
				if(!statusKey) {
					sendMessageSocket.close();
					recieveMessageSocket.close();
					return;
				}
			}
			outToServerReceiver.flush();
			outToServerSender.flush();			
			System.out.println("Client successfully registered");			
			OutputToServer outputThread = new OutputToServer(sendMessageSocket, privateKey, mode);//, outToServer, (inFromUser);
			InputFromServer inputThread = new InputFromServer(recieveMessageSocket, privateKey, mode);//, (inFromServer);
			Thread outthread = new Thread(outputThread);
			Thread inthread = new Thread(inputThread);
			outthread.start();
			inthread.start();
		}catch (Exception e) {
			// TODO: handle exception
		}

	}

	private static boolean registerToSend() throws IOException{
		boolean acks = false;
		int count=0;
		while(!acks){	
			outToServerSender.writeBytes("REGISTER TOSEND " + username + "\n\n");
			String serverMsg = inFromServerSender.readLine();
			acks = serverMsg.equals("REGISTERED TOSEND "+ username);
			String endln = inFromServerSender.readLine();

			if(acks && endln.equals(""))
				break;
			acks = false;
			if(count > REQUEST_LIMIT) {
				System.out.println("failed more than two times, returning..");
				return false;
			}
			if(serverMsg.equals(TCPClient.USER_ALREADY_REG)) {
				System.out.println("Username already in use. Please register with another username");		
			}else {
				System.out.println("Invalid username format. Please enter again");
				count++;
			}
			username = inFromUser.readLine();
		}
		return true;
	}

	private static boolean registerToRecv() throws IOException{
		outToServerReceiver.writeBytes("REGISTER TORECV " + username + "\n\n");
		String serverMsg = inFromServerReceiver.readLine();
		boolean ackr = serverMsg.equals("REGISTERED TORECV " + username);
		inFromServerReceiver.readLine();
		if(!ackr) {
			System.out.println("returning..");
			return false;
		}
		return true;
	}

	private static boolean verifyMode() throws IOException{	

		for(int i =0; i< REQUEST_LIMIT; i++){
			outToServerSender.writeBytes("MODE " + mode + "\n\n");
			String serverMsg = inFromServerSender.readLine();
			inFromServerSender.readLine();
			if(serverMsg.equals("RUNNING ON COMPATIBLE MODE")) {
				return true;
			}
			if(serverMsg.substring(0, 27).equals(INCOMPATIBLE_MODE)){
				System.out.println("Mode is incompatible with that of server. Server running on mode :" + serverMsg.substring(27));
				System.out.println("Retype mode:");
				mode = Integer.parseInt(inFromUser.readLine());
			}           
		}
		System.out.println("failed more than two times, returning..");
		return false;
	}

	private static boolean sendPublickey(String publicKeyString) throws IOException{
		outToServerSender.writeBytes("PublicKey " + publicKeyString + "\n\n");
		String serverMsg = inFromServerSender.readLine();
		if(!serverMsg.equals("REGISTERED KEY " + publicKeyString)){
			return false;
		}

		inFromServerSender.readLine();
		return true;
	}
} 