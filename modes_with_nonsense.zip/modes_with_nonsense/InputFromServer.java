import java.io.*; 
import java.net.*;

import java.security.MessageDigest;

class InputFromServer implements Runnable {
	public static final String ALGORITHM = "RSA";
	Socket connectionSocket;
	BufferedReader inFromServer;
	DataOutputStream outToServer;
	byte[] privateKey;
	int mode;

	InputFromServer (Socket connectionSocket,  byte[] privateKey, int mode){ //, BufferedReader inFromServer) {  }
		this.connectionSocket = connectionSocket;
		this.privateKey = privateKey;
		this.mode = mode;
		try{
			this.inFromServer = new BufferedReader(new InputStreamReader(this.connectionSocket.getInputStream()));
			this.outToServer = new DataOutputStream(this.connectionSocket.getOutputStream());
		} catch(Exception e){
			//e.printStackTrace();
		//	System.out.println(e+" IFS constructor");
		}

	} 

	public void run() {
		while(true) {
			try {
				boolean flag = true;
				int contentLength = 0;
				String senderUsername = null, senderUsernameLine = null, contentLengthLine = null , encryptedMsg;
				//do{

		//		System.out.println("receiving starts " );
				senderUsernameLine = inFromServer.readLine();
				if(senderUsernameLine == null){
					connectionSocket.close();
					return;
				}
				// }while(senderUsernameLine == null);
		//		System.out.println("serverMsg: "  + senderUsernameLine);
				if(senderUsernameLine.length()>=8 && senderUsernameLine.substring(0, 8).equals("FORWARD "))
					senderUsername = senderUsernameLine.substring(8);
				else{
					outToServer.writeBytes(TCPClient.HEADER_INCOMPLETE);
					continue;
					//flag = false;
				}
				//                System.out.println("sender name: "+senderUsername);
				// do{
				contentLengthLine = inFromServer.readLine();//System.out.println("serverMsg: "  + contentLengthLine);
				if(contentLengthLine == null){
					connectionSocket.close();
					return;
				}
				// }while(contentLengthLine == null);
				if(contentLengthLine.length()>16 && contentLengthLine.substring(0, 16).equals("Content-length: "))
					contentLength = Integer.parseInt(contentLengthLine.substring(16));
				else {
					outToServer.writeBytes(TCPClient.HEADER_INCOMPLETE);
					continue;
				}
					
				String endln = inFromServer.readLine();//System.out.println("serverMsg: "  + endln);
				if(endln == null){
					connectionSocket.close();
					return;
				}
				
				String hash = null;
				if(mode == TCPClient.ENCRYP_WITH_SIGN_MODE){
					hash = inFromServer.readLine();
					if(hash == null){
						connectionSocket.close();
						return;
					}
					endln = inFromServer.readLine();
					if(endln == null){
						connectionSocket.close();
						return;
					}
				}
				
				char[] msgArr = new char[contentLength];
				int readFlag  = 0;

				for(int i =0; (i<contentLength && readFlag != -1); i++){
					char[]  temparr = new char[1];
					readFlag = inFromServer.read(temparr);
					msgArr[i] = temparr[0];
				}
				if(readFlag==-1)
					encryptedMsg = "";
				else
					encryptedMsg = new String(msgArr);
				
				if(mode == TCPClient.ENCRYP_WITH_SIGN_MODE){
					outToServer.writeBytes("FETCHKEY " + senderUsername + "\n\n");

					//System.out.println("1");
					String serverMsg = inFromServer.readLine();
					if(serverMsg == null){
						connectionSocket.close();
						return;
					}
					//                System.out.println("msg from server after key fetch "  + serverMsg);
					if(serverMsg.length()<8 || !serverMsg.substring(0,8).equals("SENTKEY ")){
						outToServer.writeBytes(TCPClient.HEADER_INCOMPLETE+"\n\n");
						continue;
					}

					
					if(inFromServer.readLine() == null){
						connectionSocket.close();
						return;
					}
					//  	              System.out.println("msg from server after key fetch " + serverMsg.substring(8));

					byte[] senderPublicKey = java.util.Base64.getDecoder().decode(serverMsg.substring(8));
					//      	          System.out.println(encryptedMsg);
					byte[] hashMsgBytes = java.util.Base64.getDecoder().decode(hash);
					byte[] encryptedMsgBytes = java.util.Base64.getDecoder().decode(encryptedMsg);
					//                System.out.println(new String(encryptedMsgBytes)+" "+new String(privateKey));
					byte[] decryptedMsg  =  Cryptography.decrypt(privateKey, encryptedMsgBytes);
					byte[] decryptedhash =  Cryptography.decryptUsingPublic(senderPublicKey, hashMsgBytes);
					MessageDigest md = MessageDigest.getInstance("SHA-256");
					byte[] shaBytes = md.digest(encryptedMsgBytes);
					if((new String(shaBytes)).equals(new String(decryptedhash) )) {
						System.out.println(senderUsername + ": " + new String(decryptedMsg));
						outToServer.writeBytes("RECEIVED " + senderUsername + "\n\n");
					}
				} else if(mode == TCPClient.ENCRYP_MODE) {
					byte[] encryptedMsgBytes = java.util.Base64.getDecoder().decode(encryptedMsg);
					//                System.out.println(new String(encryptedMsgBytes)+" "+new String(privateKey));
					byte[] decryptedMsg  =  Cryptography.decrypt(privateKey, encryptedMsgBytes);
					System.out.println(senderUsername + ": " + new String(decryptedMsg));
					outToServer.writeBytes("RECEIVED " + senderUsername + "\n\n");
				}

				else{
					System.out.println(senderUsername + ": " + encryptedMsg);
					outToServer.writeBytes("RECEIVED " + senderUsername + "\n\n");
				}


			}
			catch(Exception e) {
				if(e instanceof SocketException)
					System.out.println("lost connection with server...");
				try {
					connectionSocket.close();
				} catch(Exception ee) { }
				break;
			}
		} 
	}

}
