import java.io.*;
import java.net.*;

import java.security.MessageDigest;

class OutputToServer implements Runnable {
	public static final String ALGORITHM = "RSA";
	Socket connectionSocket;
	DataOutputStream outToServer;
	BufferedReader inFromUser;
	BufferedReader inFromServer;
	byte[] privateKey;
	int mode;
   
	OutputToServer (Socket connectionSocket, byte[] privatekey, int mode){//, DataOutputStream outToServer, BufferedReader inFromUser) {
		this.connectionSocket = connectionSocket;
		this.inFromUser = new BufferedReader(new InputStreamReader(System.in));
		this.privateKey = privatekey;
		this.mode = mode;
		try{
			this.outToServer = new DataOutputStream(connectionSocket.getOutputStream());
			this.inFromServer = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
		} catch(Exception e){
			System.out.println(e + " OTS constructor");
		} 
	}

	
	public void run() {
		int errorCount =0;
		String clientSentence = null;
		while(true) {
			try {
				if(clientSentence==null) {
					outToServer.flush();
					clientSentence = inFromUser.readLine();	
				}
				if(errorCount >= TCPClient.REQUEST_LIMIT) {
					System.out.println("unable to send message, please retry");
					errorCount=0;
					clientSentence = null;
					continue;
				}
				String[] sentence_split = clientSentence.split(" ", 2);
				
				if(clientSentence.contentEquals("UNREGISTER")) {
					outToServer.writeBytes("UNREGISTER\n\n");
					return;
				}
				else if(sentence_split[0].charAt(0) != '@'){
					System.out.println("invalid message format. retype the message:");
					clientSentence=null;
					errorCount=0;
					continue;
				}
				
				String user = sentence_split[0].substring(1);
				String msg;
				
				if(sentence_split.length == 1)
					msg = "";
				else
					msg = sentence_split[1];
				
				System.out.println("message " + msg);
				
				if(mode == TCPClient.UNENCRYP_MODE){
					outToServer.writeBytes("SEND " + user + "\nContent-length: " + msg.length() + "\n\n" + msg);
					System.out.println("sent msg to server");	
				}
				else{
					outToServer.writeBytes("FETCHKEY " + user + "\n\n");
					System.out.println("fetching keuy....");	
					String serverMsg = inFromServer.readLine();
					System.out.println("server msg: " + serverMsg);
					if(serverMsg == null){
						connectionSocket.close();
						return;
					}
					
					if(serverMsg.equals(TCPClient.USER_NOTFOUND)) {
						inFromServer.readLine();
						System.out.println("Messgae sending failed - User not found...");
						outToServer.flush();
						clientSentence = null;
						errorCount = 0;
						continue;
					}
					
					if(serverMsg.length()<8 || !serverMsg.substring(0,8).equals("SENTKEY ")){
						System.out.println("error occured");
						errorCount++;
						outToServer.flush();
						continue;
					}       
					byte[] publicKey = java.util.Base64.getDecoder().decode(serverMsg.substring(8));
					serverMsg = inFromServer.readLine();
					if(serverMsg == null){
						connectionSocket.close();
						return;
					}
					
					byte[] encryptedMsgBytes = Cryptography.encrypt(publicKey, msg.getBytes());
					String encryptedMsg = java.util.Base64.getEncoder().encodeToString(encryptedMsgBytes);

					if(mode == TCPClient.ENCRYP_MODE){
						outToServer.writeBytes("SEND " + user + "\nContent-length: " + encryptedMsg.length() +"\n\n" + encryptedMsg);
					} else{
						MessageDigest md = MessageDigest.getInstance("SHA-256");
						byte[] shaBytes = md.digest(encryptedMsgBytes);
						byte[] enchash = Cryptography.encryptUsingPrivate(privateKey, shaBytes);
						String hash = java.util.Base64.getEncoder().encodeToString(enchash);
						outToServer.writeBytes("SEND " + user + "\nContent-length: " + encryptedMsg.length() + "\n\n"+ hash +"\n\n" + encryptedMsg);
					}

				}
				
				System.out.println("waiting for server.... " );
				 
//				inFromServer.wait(TCPClient.WAIT_TIME);
//				System.out.println();
//				if(!inFromServer.ready()) {
//					System.out.println("message sending to " + user + " failed");
//					errorCount++;
//					continue;
//				}
				String serverMsg = inFromServer.readLine();
				System.out.println("server msg:" + serverMsg);
				if(serverMsg == null){
					connectionSocket.close();
					return;
				}
				System.out.println("receive from server " + serverMsg);
				if(inFromServer.readLine()==null){
					connectionSocket.close();
					return;
				}
//                System.out.println("msg from server after msg sent "  + serverMsg);
							
				if(serverMsg.equals("SENT " + user))
					System.out.println("message sent sucessfully to " + user);
				else if(serverMsg.equals(TCPClient.USER_NOTFOUND)) {
					inFromServer.readLine();
					System.out.println("No such user " + user + " registered.");
				}
				else if(serverMsg.equals(TCPClient.MSG_LEN_NOT_FOUND)) {
					inFromServer.readLine();
					System.out.println("Error while sending msg. Reestablishing connection...");
					TCPClient.Register();
					return;
				}
				else 
					System.out.println("message sending to " + user + " failed");
				//serverMsg = inFromServer.readLine();
				outToServer.flush();
				clientSentence = null;
				errorCount = 0;
			} catch(Exception e) {
				try {
					connectionSocket.close();
				} catch(Exception ee) { }
				System.out.println("outputToServer "+e);
				break;
			}
		} 
	}

}
