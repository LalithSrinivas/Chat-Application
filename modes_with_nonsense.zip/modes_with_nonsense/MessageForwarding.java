import java.io.*; 
import java.net.*;
import java.nio.channels.FileChannel.MapMode; 

class MessageForwarding implements Runnable{
	String sender_username;

	MessageForwarding(String username) {
		this.sender_username = username;
	}

	public void run() {
		BufferedReader inFromClient;
		DataOutputStream clientAck;

		//System.out.println("Message ack created");

		try {
			inFromClient = new BufferedReader(new InputStreamReader(TCPServer.getUserInSocket(sender_username).getInputStream()));
			clientAck = new DataOutputStream(TCPServer.getUserInSocket(sender_username).getOutputStream());
		} catch (IOException e1) {
			e1.printStackTrace();
			// TODO Auto-generated catch block
			return;
		}


		while(true) {
			try {
				String clientReq = inFromClient.readLine();
				if(clientReq == null) {
					TCPServer.removeUser(sender_username);
					System.out.println("removed "+sender_username);
					return;						
				}
				
				if(clientReq.equals("UNREGISTER")){
					String endln = inFromClient.readLine();
					
					TCPServer.removeUser(sender_username);
					return;
				}
				
				if(TCPServer.mode != TCPServer.UNENCRYP_MODE){
					String keyRequest = clientReq;				

					if(keyRequest.length()<8 || !keyRequest.substring(0, 8).equals("FETCHKEY")){
						//clientAck.notify();
						clientAck.writeBytes(TCPServer.MALFORMED_REQUEST + "\n\n");
						continue;
					}

					String receiver_username = keyRequest.substring(9);
					
					//System.out.println(endln + " hi");

					// while(endln == null){
					// 	endln = inFromClient.readLine();
					// }
					
					String endln = inFromClient.readLine();
					if(endln == null) {
						TCPServer.removeUser(sender_username);
						System.out.println("removed "+sender_username);
						return;						
					}
					
					if(!endln.equals("")){
						//System.out.println("1");
						//clientAck.notify();
						clientAck.writeBytes(TCPServer.MALFORMED_REQUEST + "\n\n");
						continue;
					}else{
						//System.out.println("2");
						if(!TCPServer.hasUserOutSocket(receiver_username)) {
							clientAck.writeBytes(TCPServer.USER_NOTFOUND+"\n\n");
							continue;
						}
						
						clientAck.writeBytes("SENTKEY " + TCPServer.getUserPublicKey(receiver_username) + "\n\n");
					}

				}


				// String keyAck = 
				String recipientInfo;
				if(TCPServer.mode == TCPServer.UNENCRYP_MODE)
					recipientInfo = clientReq;
				else 
					recipientInfo = inFromClient.readLine();
				System.out.println("client req string: "+ recipientInfo);
				System.out.println("1");
//				if(recipientInfo == null){
//					TCPServer.removeUser(sender_username);
//					System.out.println("removed "+sender_username);
//					return;
//				}
				//                    System.out.println(recipientInfo);
				String messageLength = inFromClient.readLine();
				if(messageLength == null) {
					TCPServer.removeUser(sender_username);
					System.out.println("removed "+sender_username);
					return;
				}
				if(messageLength.length() <= 16 || !messageLength.substring(0, 16).equals("Content-length: ")){
					clientAck.writeBytes(TCPServer.MSG_LEN_NOT_FOUND +"\n\n");
					TCPServer.removeUser(sender_username);
					System.out.println("removed "+sender_username);
					return;
				}
				
				int len = Integer.parseInt(messageLength.substring(16));
				//                        System.out.println("message length: " + len);
				String message = inFromClient.readLine();

				String hash =null;

				if(TCPServer.mode == TCPServer.ENCRYP_WITH_SIGN_MODE){
					hash = inFromClient.readLine();	
					message = inFromClient.readLine();
				} 

				char[] msgArr = new char[len];
				//				int check = inFromClient.read(msgArr, 0, len);
				//				System.out.println(check);
				int flag  = 0;
				for(int i =0; i<len && flag != -1; i++){
					char[]  temparr = new char[1];
					flag = inFromClient.read(temparr);
					msgArr[i] = temparr[0];
				}
				if(flag==-1)
					message = "";
				else
					message = new String(msgArr);
				//System.out.println("message: " + message);
				if(recipientInfo.substring(0, 4).equals("SEND")) {
					//                   	System.out.println("message: "+message);
					String recipientName = recipientInfo.substring(5);
					if(!TCPServer.hasUserOutSocket(recipientName)) {
						clientAck.writeBytes(TCPServer.USER_NOTFOUND+"\n\n");
						continue;
					}
					Socket outsocket = TCPServer.getUserOutSocket(recipientName);
					if(outsocket != null) {
						DataOutputStream  outToClient = new DataOutputStream(outsocket.getOutputStream());
						try {
							if(messageLength.substring(0, 15).equals("Content-length:")) {
								int length = Integer.parseInt(messageLength.substring(16));
								if(TCPServer.mode!=TCPServer.ENCRYP_WITH_SIGN_MODE)
									outToClient.writeBytes("FORWARD "+sender_username+"\n"+"Content-length: "+length+"\n\n"+message);
								else
									outToClient.writeBytes("FORWARD "+sender_username+"\n"+"Content-length: "+length+"\n\n"+hash+"\n\n"+message);
							}
							else {
								//clientAck.notify();
								clientAck.writeBytes(TCPServer.HEADER_INCOMPLETE+"\n\n");
								continue;
							}
						}
						catch (Exception e) {
						//	System.out.println(e);
							//clientAck.notify();
							clientAck.writeBytes(TCPServer.HEADER_INCOMPLETE+ "\n\n");
							continue;
							// TODO: handle exception
						}
					}
					else {
						//clientAck.notify();
						clientAck.writeBytes(TCPServer.UNABLE_TOSEND+"\n\n");
					}
				}
			}
			catch(Exception e) {
				//e.printStackTrace();
				//System.out.println(e);
				try {
					TCPServer.removeUser(sender_username);
				} catch (IOException e1) {				}
				return;
			}
		}
	}
}