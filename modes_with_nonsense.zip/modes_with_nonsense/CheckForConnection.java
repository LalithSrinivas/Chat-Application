import java.io.*; 
import java.net.*; 
import java.util.regex.Pattern;


class CheckForConnection implements Runnable{
	Socket connectionSocket;
	int mode;
	int count = 0;
	CheckForConnection(Socket socket, int mode ){
		this.connectionSocket = socket;
		this.mode = mode;
	}

	public boolean checkUsername(String username) {
		return Pattern.matches("[a-zA-Z0-9]+", username);
	}

	public void run() {
		try {
			BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
			DataOutputStream  outToClient = new DataOutputStream(connectionSocket.getOutputStream());
			//waits till it receives some message
			String requestSentence = null, endln, username = null;

			requestSentence= inFromClient.readLine();
			if(requestSentence == null) {
				connectionSocket.close();
				return;
			}

			if(!requestSentence.substring(0, 16).equals("REGISTER TOSEND ") && !requestSentence.substring(0, 16).equals("REGISTER TORECV ")){
				outToClient.writeBytes(TCPServer.USER_NOTFOUND + "\n\n");
				this.connectionSocket.close();
				return;
			}

			endln = inFromClient.readLine();
			if(endln == null) {
				connectionSocket.close();
				return;
			}
			username = requestSentence.substring(16);

			if(requestSentence.subSequence(0, 16).equals("REGISTER TORECV ")) {//request to register to receive
				if(TCPServer.hasUserOutSocket(username)) {
					outToClient.writeBytes(TCPServer.USER_ALREADY_REG +"\n\n");
					this.run();//System.out.println("1");
					return;
				}
				if(!checkUsername(username)) {
					outToClient.writeBytes(TCPServer.MALFORMED_USERNAME +"\n\n");
					this.run();//System.out.println("1");
					return;
				} 
				TCPServer.addUserOutSocket(username, connectionSocket);
				outToClient.writeBytes("REGISTERED TORECV "+username+"\n\n");
				//System.out.println("Registered to receive " + username);
				MessageAck initConvA = new MessageAck(username);
				initConvA.run();
				return;
			}
			else if(requestSentence.subSequence(0, 16).equals("REGISTER TOSEND ")) {//request to register tosend
				if(TCPServer.hasUserInSocket(username)) {
					outToClient.writeBytes(TCPServer.USER_ALREADY_REG +"\n\n");
					this.run();
					return;
				}
				else if(!checkUsername(username)) {
					outToClient.writeBytes(TCPServer.MALFORMED_USERNAME +"\n\n");
					this.run();
					return;
				}
					TCPServer.addUserInSocket(username, connectionSocket);
					outToClient.writeBytes("REGISTERED TOSEND "+username+"\n\n");
					//System.out.println("Registered to send " + username);
				

				int clientMode = -1;
				//if client mode and server mode aren't matching request for new mode 3 times
				//if modes don't match even after 3 times destroy socket;
				for(int i =0; i<TCPServer.REQUESTS_LIMIT; i++){
					requestSentence = inFromClient.readLine();//System.out.println(requestSentence);
					if(requestSentence == null) {
						TCPServer.removeUser(username);
						connectionSocket.close();
						return;
					}
					endln = inFromClient.readLine();
					if(endln == null) {
						TCPServer.removeUser(username);
						connectionSocket.close();
						return;
					}

					clientMode = Integer.parseInt(requestSentence.substring(5));
				//	System.out.println("clientmode:" + clientMode);
					if(clientMode != this.mode){
						outToClient.writeBytes(TCPServer.INCOMPATIBLE_MODE + " " + this.mode + "\n\n");
					} else{
						outToClient.writeBytes("RUNNING ON COMPATIBLE MODE\n\n");
						break;
					}
				}

				if(clientMode != this.mode){
					TCPServer.removeUser(username);
					return;
				}


				if(this.mode != TCPServer.UNENCRYP_MODE){
					requestSentence = inFromClient.readLine();
				//	System.out.println(requestSentence);
					if(requestSentence == null) {
						TCPServer.removeUser(username);
						connectionSocket.close();
						return;
					}
					endln = inFromClient.readLine();
					if(endln == null) {
						TCPServer.removeUser(username);
						connectionSocket.close();
						return;
					}

					String publicKey = requestSentence.substring(10);

					TCPServer.addUserPublicKey(username, publicKey);
					outToClient.writeBytes("REGISTERED KEY "+publicKey+"\n\n");
				}							
			}

			System.out.println("Registered " + username);
			MessageForwarding initConvF = new MessageForwarding(username);
			initConvF.run();	
		} 
		catch(Exception e) {
			System.out.println("Error at Server while accepting request: "+ e);
			try{
				//outToClient.writeBytes(MALFORMED_REQUEST + "\n\n");
				connectionSocket.close();
			} catch (IOException e1) {
				System.out.println(e1);
				return;
			}
		}
	}
}
